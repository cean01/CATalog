// GET: who am I (profile, role, permissions, app settings).
// PUT: update my display name.
import { db } from 'hatchable';
import { getActor, permsFor, route, settings, str } from 'lib/core.js';

export const access = 'user';
export const methods = ['GET', 'PUT'];

function out(p, s) {
  return {
    id: p.user_id,
    email: p.email,
    full_name: p.full_name,
    role: p.role,
    is_active: p.is_active,
    created_at: p.created_at,
    permissions: permsFor(p.role),
    needs_name: !p.full_name,
    settings: s,
  };
}

export default route(async (req, res) => {
  let me = await getActor(req);
  if (req.method === 'PUT') {
    const name = str(req.body, 'full_name', { max: 120, required: true, label: 'Name' });
    me = (await db.query('UPDATE app_profiles SET full_name = $2 WHERE user_id = $1 RETURNING *', [me.user_id, name])).rows[0];
  } else {
    await db.query(
      `UPDATE app_profiles SET last_seen_at = now() WHERE user_id = $1 AND (last_seen_at IS NULL OR last_seen_at < now() - interval '10 minutes')`,
      [me.user_id],
    );
  }
  res.json(out(me, await settings()));
});