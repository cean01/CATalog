-- CAT-TRACK schema. Integrity rules live in PostgreSQL itself, not only in
-- the API: unique codes/tokens, server-stamped and append-only activities,
-- valid coordinates, and an audit trail.

CREATE TYPE app_role        AS ENUM ('admin', 'feeder', 'resident');
CREATE TYPE cat_gender      AS ENUM ('male', 'female', 'unknown');
CREATE TYPE cat_status      AS ENUM ('active', 'missing', 'adopted', 'deceased', 'archived');
CREATE TYPE activity_type   AS ENUM ('feeding', 'sighting');
CREATE TYPE activity_method AS ENUM ('qr_scan', 'manual');

CREATE OR REPLACE FUNCTION set_updated_at() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  NEW.updated_at := now();
  RETURN NEW;
END $$;

-- One row per platform account (the platform owns identity; this table
-- holds the CAT-TRACK role). user_id is the platform's opaque TEXT id.
CREATE TABLE app_profiles (
  user_id     TEXT PRIMARY KEY,
  email       TEXT NOT NULL,
  full_name   VARCHAR(120) NOT NULL DEFAULT '',
  role        app_role NOT NULL DEFAULT 'resident',
  is_active   BOOLEAN NOT NULL DEFAULT true,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
  last_seen_at TIMESTAMPTZ
);
CREATE INDEX app_profiles_role_idx ON app_profiles (role);
CREATE INDEX app_profiles_email_idx ON app_profiles (lower(email));
CREATE TRIGGER app_profiles_updated_at BEFORE UPDATE ON app_profiles
  FOR EACH ROW EXECUTE FUNCTION set_updated_at();

CREATE SEQUENCE cat_code_seq START 1;

CREATE TABLE cats (
  id                    UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  cat_code              VARCHAR(20) NOT NULL UNIQUE
                          DEFAULT 'CAT-' || lpad(nextval('cat_code_seq')::text, 5, '0'),
  name                  VARCHAR(80) NOT NULL CHECK (length(btrim(name)) > 0),
  gender                cat_gender NOT NULL DEFAULT 'unknown',
  color                 VARCHAR(80) NOT NULL CHECK (length(btrim(color)) > 0),
  distinguishing_marks  TEXT CHECK (length(distinguishing_marks) <= 1000),
  photo_key             TEXT,
  thumb_key             TEXT,
  status                cat_status NOT NULL DEFAULT 'active',
  registration_location VARCHAR(200),
  registration_notes    TEXT CHECK (length(registration_notes) <= 2000),
  registered_by         TEXT NOT NULL REFERENCES app_profiles(user_id),
  registered_at         TIMESTAMPTZ NOT NULL DEFAULT now(),
  qr_token              VARCHAR(64) NOT NULL UNIQUE CHECK (length(qr_token) >= 32),
  qr_token_rotated_at   TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at            TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER SEQUENCE cat_code_seq OWNED BY cats.cat_code;
CREATE INDEX cats_status_idx ON cats (status);
CREATE INDEX cats_name_idx ON cats (lower(name));
CREATE TRIGGER cats_updated_at BEFORE UPDATE ON cats
  FOR EACH ROW EXECUTE FUNCTION set_updated_at();

CREATE TABLE activities (
  id                  BIGSERIAL PRIMARY KEY,
  cat_id              UUID NOT NULL REFERENCES cats(id) ON DELETE RESTRICT,
  user_id             TEXT NOT NULL REFERENCES app_profiles(user_id) ON DELETE RESTRICT,
  activity_type       activity_type NOT NULL,
  method              activity_method NOT NULL,
  recorded_at         TIMESTAMPTZ NOT NULL DEFAULT now(),
  latitude            NUMERIC(9,6) CHECK (latitude BETWEEN -90 AND 90),
  longitude           NUMERIC(9,6) CHECK (longitude BETWEEN -180 AND 180),
  location_accuracy_m NUMERIC(8,1) CHECK (location_accuracy_m >= 0),
  location_label      VARCHAR(200),
  notes               TEXT CHECK (length(notes) <= 1000),
  client_request_id   UUID,
  CONSTRAINT activities_latlon_pair CHECK ((latitude IS NULL) = (longitude IS NULL)),
  CONSTRAINT activities_idempotency UNIQUE (user_id, client_request_id)
);
CREATE INDEX activities_cat_type_time_idx ON activities (cat_id, activity_type, recorded_at DESC);
CREATE INDEX activities_time_idx ON activities (recorded_at DESC);
CREATE INDEX activities_user_time_idx ON activities (user_id, recorded_at DESC);

-- The server clock is the only source of truth for when an activity happened.
CREATE OR REPLACE FUNCTION activities_stamp_time() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  NEW.recorded_at := now();
  RETURN NEW;
END $$;
CREATE TRIGGER activities_stamp BEFORE INSERT ON activities
  FOR EACH ROW EXECUTE FUNCTION activities_stamp_time();

-- History can be added to but never edited or erased.
CREATE OR REPLACE FUNCTION activities_append_only() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  RAISE EXCEPTION 'activities are append-only (% blocked)', TG_OP;
END $$;
CREATE TRIGGER activities_no_change BEFORE UPDATE OR DELETE ON activities
  FOR EACH ROW EXECUTE FUNCTION activities_append_only();

CREATE TABLE audit_logs (
  id          BIGSERIAL PRIMARY KEY,
  actor_id    TEXT,
  action      VARCHAR(60) NOT NULL,
  entity_type VARCHAR(40) NOT NULL,
  entity_id   VARCHAR(64),
  details     JSONB,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX audit_logs_time_idx ON audit_logs (created_at DESC);