// GET /api/audit  administrative change log (administrators)
import { db } from 'hatchable';
import { P, getActor, pageParams, requirePerm, route } from 'lib/core.js';

export const access = 'user';
export const methods = ['GET'];

export default route(async (req, res) => {
  const actor = await getActor(req);
  requirePerm(actor, P.AUDIT, 'Only administrators can read the audit log.');
  const { page, size, offset } = pageParams(req.query || {}, 30);
  const total = (await db.query('SELECT count(*)::int AS n FROM audit_logs')).rows[0].n;
  const { rows } = await db.query(
    `SELECT l.id, l.action, l.entity_type, l.entity_id, l.details, l.created_at,
            p.full_name AS actor_name, p.email AS actor_email
     FROM audit_logs l LEFT JOIN app_profiles p ON p.user_id = l.actor_id
     ORDER BY l.created_at DESC, l.id DESC LIMIT $1 OFFSET $2`,
    [size, offset],
  );
  res.json({ items: rows, total, page, page_size: size });
});