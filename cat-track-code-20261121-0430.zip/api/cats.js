// GET  /api/cats   searchable, filterable, paginated catalog (all roles)
// POST /api/cats   register a cat (administrators)
import { db } from 'hatchable';
import {
  GENDERS, P, STATUSES, audit, fail, getActor, newToken, oneOf, pageParams, requirePerm, route, str,
} from 'lib/core.js';
import { listCats, loadCatRow, toCat } from 'lib/cats.js';

export const access = 'user';
export const methods = ['GET', 'POST'];

export default route(async (req, res) => {
  const actor = await getActor(req);

  if (req.method === 'GET') {
    requirePerm(actor, P.CAT_READ);
    const q = req.query || {};
    const { page, size, offset } = pageParams(q);
    const search = typeof q.q === 'string' ? q.q.trim().slice(0, 100) : '';
    const sort = ['name', 'code', 'newest', 'last_fed', 'last_seen'].includes(q.sort) ? q.sort : 'name';
    const status = oneOf(q.status, STATUSES, 'Status');
    if (status === 'archived') requirePerm(actor, P.CAT_WRITE);
    const data = await listCats(actor, {
      q: search || null, gender: oneOf(q.gender, GENDERS, 'Gender'), status, sort, size, offset,
    });
    return res.json({ ...data, page, page_size: size });
  }

  requirePerm(actor, P.CAT_WRITE, 'Only administrators can register cats.');
  const b = req.body || {};
  const values = [
    str(b, 'name', { max: 80, required: true, label: 'Name' }),
    oneOf(b.gender, GENDERS, 'Gender') || 'unknown',
    str(b, 'color', { max: 80, required: true, label: 'Color' }),
    str(b, 'distinguishing_marks', { max: 1000, label: 'Distinguishing marks' }),
    str(b, 'registration_location', { max: 200, label: 'Registration location' }),
    str(b, 'registration_notes', { max: 2000, label: 'Registration notes' }),
    actor.user_id,
    newToken(),
  ];
  const { rows } = await db.query(
    `INSERT INTO cats (name, gender, color, distinguishing_marks, registration_location, registration_notes,
                       registered_by, qr_token)
     VALUES ($1, $2::cat_gender, $3, $4, $5, $6, $7, $8) RETURNING id, cat_code`,
    values,
  );
  if (!rows[0]) fail(500, 'Could not register the cat.');
  await audit(actor.user_id, 'cat.create', 'cat', rows[0].id, { cat_code: rows[0].cat_code, name: values[0] });
  res.status(201).json(await toCat(await loadCatRow(rows[0].id), actor, { full: true }));
});