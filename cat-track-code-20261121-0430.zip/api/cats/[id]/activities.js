// GET  /api/cats/:id/activities  history (feeders/admins: all; residents: own)
// POST /api/cats/:id/activities  Record Feeding / Record Sighting
//
// Saved for every activity: cat id, logged-in user, SERVER timestamp (set by
// a DB trigger, never by the client), optional GPS + place label + notes.
// client_request_id makes retries safe: the same submission sent twice
// (flaky mobile data) is stored once.
import { db } from 'hatchable';
import {
  P, can, fail, getActor, num, oneOf, pageParams, requirePerm, route, safeEqual, str, uuidParam,
} from 'lib/core.js';
import { ACTIVITY_SELECT, getVisibleCat, listActivities, toActivity } from 'lib/cats.js';

export const access = 'user';
export const methods = ['GET', 'POST'];

const ALLOWED_STATUS = { feeding: ['active'], sighting: ['active', 'missing'] };
const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

async function byRequestId(userId, requestId) {
  const { rows } = await db.query(`${ACTIVITY_SELECT} WHERE a.user_id = $1 AND a.client_request_id = $2`, [userId, requestId]);
  return rows[0] || null;
}

export default route(async (req, res) => {
  const actor = await getActor(req);
  const catId = uuidParam(req.params.id, 'cat');
  const cat = await getVisibleCat(actor, catId);

  if (req.method === 'GET') {
    const q = req.query || {};
    const { page, size, offset } = pageParams(q);
    const type = oneOf(q.type, ['feeding', 'sighting'], 'Type');
    const data = await listActivities(actor, { catId, type, size, offset });
    return res.json({ ...data, page, page_size: size });
  }

  const b = req.body || {};
  const type = oneOf(b.activity_type, ['feeding', 'sighting'], 'Activity type');
  if (!type) fail(422, 'Activity type is required.');
  requirePerm(actor, type === 'feeding' ? P.FEEDING : P.SIGHTING, `Your role cannot record a ${type}.`);

  const method = oneOf(b.method, ['qr_scan', 'manual'], 'Method') || 'manual';
  let requestId = null;
  if (b.client_request_id != null) {
    if (typeof b.client_request_id !== 'string' || !UUID_RE.test(b.client_request_id)) fail(422, 'client_request_id must be a UUID.');
    requestId = b.client_request_id.toLowerCase();
    const prior = await byRequestId(actor.user_id, requestId);
    if (prior) {
      if (prior.cat_id !== catId || prior.activity_type !== type) fail(409, 'This request ID was already used for a different record.');
      return res.status(200).json({ activity: toActivity(prior), duplicate: true });
    }
  }

  if (!ALLOWED_STATUS[type].includes(cat.status)) {
    fail(422, `Cannot record a ${type} for a cat marked "${cat.status}".`);
  }
  if (method === 'qr_scan') {
    // Proves the person actually scanned this cat's current physical tag.
    requirePerm(actor, P.SCAN, 'Your role cannot record via QR scan.');
    if (!b.qr_token || !safeEqual(b.qr_token, cat.qr_token)) {
      fail(422, 'The scanned tag does not match this cat (it may have been replaced).');
    }
  }

  const lat = num(b.latitude, { min: -90, max: 90, label: 'Latitude' });
  const lon = num(b.longitude, { min: -180, max: 180, label: 'Longitude' });
  if ((lat === null) !== (lon === null)) fail(422, 'Latitude and longitude must be given together.');
  const acc = lat === null ? null : num(b.location_accuracy_m, { min: 0, max: 100000, label: 'Accuracy' });

  const ins = await db.query(
    `INSERT INTO activities (cat_id, user_id, activity_type, method, latitude, longitude, location_accuracy_m,
                             location_label, notes, client_request_id)
     VALUES ($1, $2, $3::activity_type, $4::activity_method, $5, $6, $7, $8, $9, $10)
     ON CONFLICT (user_id, client_request_id) DO NOTHING
     RETURNING id`,
    [
      catId, actor.user_id, type, method,
      lat === null ? null : lat.toFixed(6), lon === null ? null : lon.toFixed(6), acc,
      str(b, 'location_label', { max: 200, label: 'Place' }),
      str(b, 'notes', { max: 1000, label: 'Notes' }),
      requestId,
    ],
  );
  if (!ins.rows[0]) {
    // Two identical retries raced; return the one that won.
    const prior = requestId && (await byRequestId(actor.user_id, requestId));
    if (prior) return res.status(200).json({ activity: toActivity(prior), duplicate: true });
    fail(409, 'Could not save. Please try again.');
  }
  const saved = (await db.query(`${ACTIVITY_SELECT} WHERE a.id = $1`, [ins.rows[0].id])).rows[0];
  res.status(201).json({ activity: toActivity(saved), duplicate: false });
});