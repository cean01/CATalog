// App entry: loads the session, renders the shell and routes.
import { Link, PERM, ROLE, SessionCtx, ToastProvider, api, html, match, useEffect, useLocation, useState } from './lib.js';
import { Button, ErrorBox, Field, Loader } from './components.js';
import { CatFormPage, CatPage, CatalogPage, TagPage } from './pages-cats.js';
import { ResolvePage, ScanPage } from './pages-scan.js';
import { AuditPage, DashboardPage, MePage, UsersPage } from './pages-admin.js';

const ICON = {
  list: 'M4 6h16M4 12h16M4 18h10',
  scan: 'M4 8V5a1 1 0 0 1 1-1h3M16 4h3a1 1 0 0 1 1 1v3M20 16v3a1 1 0 0 1-1 1h-3M8 20H5a1 1 0 0 1-1-1v-3M7 12h10',
  chart: 'M5 20V10M12 20V4M19 20v-7',
  users: 'M16 19v-1a4 4 0 0 0-4-4H7a4 4 0 0 0-4 4v1M9.5 10a3.5 3.5 0 1 0 0-7 3.5 3.5 0 0 0 0 7M21 19v-1a4 4 0 0 0-3-3.9M15 3.1a3.5 3.5 0 0 1 0 6.8',
  me: 'M12 12a4 4 0 1 0 0-8 4 4 0 0 0 0 8M4 21a8 8 0 0 1 16 0',
};
const Svg = ({ d }) => html`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d=${d} /></svg>`;

function Tab({ to, label, d, active, big }) {
  return html`<${Link} to=${to} class=${'tab' + (active ? ' active' : '') + (big ? ' scan' : '')} aria-current=${active ? 'page' : undefined}>
    ${big ? html`<span class="bubble"><${Svg} d=${d} /></span>` : html`<${Svg} d=${d} />`}${label}
  <//>`;
}

function Forbidden() {
  return html`<div class="stack"><${ErrorBox} msg="Your role does not have access to this page." /><${Link} to="/" class="btn secondary">Back to catalog<//></div>`;
}

function Routes({ path, can }) {
  let p;
  if (path === '/' || path === '') return html`<${CatalogPage} />`;
  if (path === '/cats/new') return can(PERM.CAT_WRITE) ? html`<${CatFormPage} />` : html`<${Forbidden} />`;
  if ((p = match('/cats/:id/edit', path))) return can(PERM.CAT_WRITE) ? html`<${CatFormPage} id=${p.id} />` : html`<${Forbidden} />`;
  if ((p = match('/cats/:id/tag', path))) return can(PERM.CAT_QR) ? html`<${TagPage} id=${p.id} />` : html`<${Forbidden} />`;
  if ((p = match('/cats/:id', path))) return html`<${CatPage} key=${p.id} id=${p.id} />`;
  if (path === '/scan') return can(PERM.SCAN) ? html`<${ScanPage} />` : html`<${Forbidden} />`;
  if ((p = match('/s/:token', path))) {
    return can(PERM.SCAN) ? html`<${ResolvePage} token=${p.token} />`
      : html`<div class="stack"><${ErrorBox} msg="This is a CAT-TRACK cat tag. Only community feeders and administrators can open tags. You can still find cats in the catalog." /><${Link} to="/" class="btn">Open catalog<//></div>`;
  }
  if (path === '/admin') return can(PERM.DASHBOARD) ? html`<${DashboardPage} />` : html`<${Forbidden} />`;
  if (path === '/admin/users') return can(PERM.USERS) ? html`<${UsersPage} />` : html`<${Forbidden} />`;
  if (path === '/admin/audit') return can(PERM.AUDIT) ? html`<${AuditPage} />` : html`<${Forbidden} />`;
  if (path === '/me') return html`<${MePage} />`;
  return html`<div class="stack"><h1>Page not found</h1><${Link} to="/" class="btn">Go to catalog<//></div>`;
}

/** First sign-in: ask for a display name so records show who did them. */
function NamePrompt({ onDone }) {
  const [name, setName] = useState('');
  const [err, setErr] = useState(null);
  const [busy, setBusy] = useState(false);
  async function save(e) {
    e.preventDefault(); setBusy(true); setErr(null);
    try { onDone(await api('/me', { method: 'PUT', body: { full_name: name } })); } catch (x) { setErr(x.message); } finally { setBusy(false); }
  }
  return html`<form class="stack" onSubmit=${save}>
    <h1>Welcome to CAT-TRACK</h1>
    <p class="muted">What name should appear on the feedings and sightings you record?</p>
    <${Field} label="Your name"><input class="input" required maxlength="120" autocomplete="name" value=${name} onChange=${(e) => setName(e.target.value)} /><//>
    <${ErrorBox} msg=${err} />
    <${Button} type="submit" class="block" loading=${busy} disabled=${!name.trim()}>Continue<//>
  </form>`;
}

function App() {
  const { path } = useLocation();
  const [me, setMe] = useState(null);
  const [err, setErr] = useState(null);

  useEffect(() => {
    api('/me').then(setMe).catch((e) => setErr(e.message));
    // Re-check role/permissions when the app comes back into view, so a
    // promotion (e.g. Resident -> Community Feeder) shows without a manual reload.
    const refresh = () => {
      if (document.visibilityState === 'visible') api('/me').then(setMe).catch(() => {});
    };
    document.addEventListener('visibilitychange', refresh);
    window.addEventListener('focus', refresh);
    return () => {
      document.removeEventListener('visibilitychange', refresh);
      window.removeEventListener('focus', refresh);
    };
  }, []);

  if (err) return html`<div class="shell"><main class="stack"><h1>CAT-TRACK</h1><${ErrorBox} msg=${err} />
    <${Button} kind="secondary" onClick=${() => window.hatchable.auth.signOut().finally(() => { location.href = '/login'; })}>Sign out<//></main></div>`;
  if (!me) return html`<${Loader} />`;

  const can = (perm) => me.permissions.includes(perm);
  const session = { me, setMe, can, settings: me.settings };
  const at = (prefix) => (prefix === '/' ? path === '/' || path.startsWith('/cats') : path === prefix || path.startsWith(prefix + '/'));

  return html`<${SessionCtx.Provider} value=${session}>
    <div class="shell">
      <header class="topbar">
        <img class="logo" src="/icons/icon.svg" alt="" />
        <span class="title">CAT-TRACK</span>
        <span class="spacer"></span>
        <span class="role" title=${ROLE[me.role]}>${me.role}</span>
      </header>
      <main>${me.needs_name ? html`<${NamePrompt} onDone=${setMe} />` : html`<${Routes} path=${path} can=${can} />`}</main>
      <nav class="tabbar" aria-label="Main">
        <div class="inner">
          <${Tab} to="/" label="Cats" d=${ICON.list} active=${at('/')} />
          ${can(PERM.SCAN) ? html`<${Tab} to="/scan" label="Scan" d=${ICON.scan} active=${at('/scan') || at('/s')} big=${true} />` : null}
          ${can(PERM.DASHBOARD) ? html`<${Tab} to="/admin" label="Dashboard" d=${ICON.chart} active=${path === '/admin' || path === '/admin/audit'} />` : null}
          ${can(PERM.USERS) ? html`<${Tab} to="/admin/users" label="Users" d=${ICON.users} active=${path === '/admin/users'} />` : null}
          <${Tab} to="/me" label="Me" d=${ICON.me} active=${at('/me')} />
        </div>
      </nav>
    </div>
  <//>`;
}

ReactDOM.createRoot(document.getElementById('root')).render(html`<${ToastProvider}><${App} /><//>`);

if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => navigator.serviceWorker.register('/sw.js').catch(() => {}));
}