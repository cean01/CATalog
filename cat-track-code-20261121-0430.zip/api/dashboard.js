// GET /api/dashboard  administrator summary, computed live from the database.
import { db } from 'hatchable';
import { P, getActor, requirePerm, route, settings } from 'lib/core.js';

export const access = 'user';
export const methods = ['GET'];

const LATEST = `
  LEFT JOIN LATERAL (SELECT max(recorded_at) AS t FROM activities a
    WHERE a.cat_id = c.id AND a.activity_type = 'feeding') f ON true
  LEFT JOIN LATERAL (SELECT max(recorded_at) AS t FROM activities a
    WHERE a.cat_id = c.id AND a.activity_type = 'sighting') s ON true`;

export default route(async (req, res) => {
  const actor = await getActor(req);
  requirePerm(actor, P.DASHBOARD, 'Only administrators can view the dashboard.');
  const { timezone } = await settings();

  const [byStatus, byRole, today, notFed, notSeen, daily, top] = await Promise.all([
    db.query('SELECT status, count(*)::int AS n FROM cats GROUP BY status'),
    db.query('SELECT role, count(*)::int AS n FROM app_profiles WHERE is_active GROUP BY role'),
    db.query(
      `SELECT activity_type, count(*)::int AS n FROM activities
       WHERE recorded_at >= (date_trunc('day', now() AT TIME ZONE $1) AT TIME ZONE $1)
       GROUP BY activity_type`,
      [timezone],
    ),
    db.query(
      `SELECT c.id, c.cat_code, c.name, f.t AS last_fed_at, s.t AS last_seen_at FROM cats c ${LATEST}
       WHERE c.status = 'active' AND (f.t IS NULL OR f.t < now() - interval '24 hours')
       ORDER BY f.t ASC NULLS FIRST LIMIT 10`,
    ),
    db.query(
      `SELECT c.id, c.cat_code, c.name, f.t AS last_fed_at, s.t AS last_seen_at FROM cats c ${LATEST}
       WHERE c.status = 'active' AND (greatest(f.t, s.t) IS NULL OR greatest(f.t, s.t) < now() - interval '7 days')
       ORDER BY greatest(f.t, s.t) ASC NULLS FIRST LIMIT 10`,
    ),
    db.query(
      `SELECT to_char(d, 'YYYY-MM-DD') AS day,
              count(a.id) FILTER (WHERE a.activity_type = 'feeding')::int AS feedings,
              count(a.id) FILTER (WHERE a.activity_type = 'sighting')::int AS sightings
       FROM generate_series((now() AT TIME ZONE $1)::date - 13, (now() AT TIME ZONE $1)::date, interval '1 day') d
       LEFT JOIN activities a ON (a.recorded_at AT TIME ZONE $1)::date = d::date
       GROUP BY d ORDER BY d`,
      [timezone],
    ),
    db.query(
      `SELECT p.user_id, p.full_name, count(a.id)::int AS feedings
       FROM activities a JOIN app_profiles p ON p.user_id = a.user_id
       WHERE a.activity_type = 'feeding' AND a.recorded_at >= now() - interval '7 days'
       GROUP BY p.user_id, p.full_name ORDER BY feedings DESC LIMIT 5`,
    ),
  ]);

  const status = { active: 0, missing: 0, adopted: 0, deceased: 0, archived: 0 };
  for (const r of byStatus.rows) status[r.status] = r.n;
  const roles = { admin: 0, feeder: 0, resident: 0 };
  for (const r of byRole.rows) roles[r.role] = r.n;
  const t = Object.fromEntries(today.rows.map((r) => [r.activity_type, r.n]));

  res.json({
    cats_by_status: status,
    total_cats: status.active + status.missing + status.adopted + status.deceased,
    users_by_role: roles,
    feedings_today: t.feeding || 0,
    sightings_today: t.sighting || 0,
    not_fed_24h: notFed.rows,
    not_seen_7d: notSeen.rows,
    last_14_days: daily.rows,
    top_feeders_7d: top.rows,
    timezone,
  });
});