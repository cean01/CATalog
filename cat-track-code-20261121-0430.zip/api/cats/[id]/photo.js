// POST /api/cats/:id/photo  (administrators)
// Body: { image: <base64 JPEG>, thumb: <base64 JPEG> }
// The browser resizes and re-encodes the photo before upload (which also
// strips phone EXIF/GPS metadata), so uploads stay small on mobile data.
// The server accepts only real JPEG bytes within size limits.
import { db, storage } from 'hatchable';
import { Buffer } from 'node:buffer';
import { P, audit, fail, getActor, requirePerm, route, uuidParam } from 'lib/core.js';
import { loadCatRow, toCat } from 'lib/cats.js';

export const access = 'user';
export const methods = ['POST'];

const MAX_FULL = 1_500_000;
const MAX_THUMB = 250_000;

function decodeJpeg(b64, max, label) {
  if (typeof b64 !== 'string' || !b64) fail(422, `${label} is missing.`);
  const clean = b64.replace(/^data:image\/jpeg;base64,/, '');
  if (clean.length > Math.ceil((max * 4) / 3) + 8) fail(413, `${label} is too large.`);
  if (!/^[A-Za-z0-9+/]+={0,2}$/.test(clean)) fail(422, `${label} is not valid base64.`);
  const buf = Buffer.from(clean, 'base64');
  // JPEG magic bytes: FF D8 FF ... and end marker FF D9
  if (buf.length < 100 || buf[0] !== 0xff || buf[1] !== 0xd8 || buf[2] !== 0xff) fail(415, `${label} must be a JPEG image.`);
  if (buf.length > max) fail(413, `${label} is too large.`);
  return buf;
}

function rid() {
  const b = new Uint8Array(12);
  crypto.getRandomValues(b);
  return Array.from(b, (x) => x.toString(16).padStart(2, '0')).join('');
}

export default route(async (req, res) => {
  const actor = await getActor(req);
  requirePerm(actor, P.CAT_WRITE, 'Only administrators can change cat photos.');
  const id = uuidParam(req.params.id, 'cat');
  const before = await loadCatRow(id);
  if (!before) fail(404, 'Cat not found.');

  const full = decodeJpeg(req.body && req.body.image, MAX_FULL, 'Photo');
  const thumb = decodeJpeg(req.body && req.body.thumb, MAX_THUMB, 'Thumbnail');
  const base = `cats/${id}/${rid()}`;
  await storage.put(`${base}.jpg`, full, 'image/jpeg');
  await storage.put(`${base}_thumb.jpg`, thumb, 'image/jpeg');
  await db.query('UPDATE cats SET photo_key = $2, thumb_key = $3 WHERE id = $1', [id, `${base}.jpg`, `${base}_thumb.jpg`]);
  await audit(actor.user_id, 'cat.photo', 'cat', id, { bytes: full.length });

  for (const k of [before.photo_key, before.thumb_key]) {
    if (k) { try { await storage.del(k); } catch { /* already gone */ } }
  }
  res.json(await toCat(await loadCatRow(id), actor, { full: true }));
});