// Catalog, cat profile, register/edit form, printable QR tag.
import {
  GENDER, Link, PERM, api, fmtDate, fmtDateTime, html, navigate, preparePhoto, qs, timeAgo, useEffect, useLocation,
  useRef, useSession, useState, useToast,
} from './lib.js';
import {
  Button, CatPhoto, CatRow, Empty, ErrorBox, FedDot, Field, Loader, QrSvg, RecordSheet, StatusBadge,
} from './components.js';

// ---------------- Catalog ----------------
export function CatalogPage() {
  const { can } = useSession();
  const { search } = useLocation();
  const q = search.get('q') || '';
  const status = search.get('status') || '';
  const gender = search.get('gender') || '';
  const sort = search.get('sort') || 'name';
  const [text, setText] = useState(q);
  const [data, setData] = useState(null);
  const [page, setPage] = useState(1);
  const [loading, setLoading] = useState(true);
  const [err, setErr] = useState(null);

  const setParam = (k, v) => {
    const p = new URLSearchParams(location.search);
    if (v) p.set(k, v); else p.delete(k);
    const s = p.toString();
    navigate('/' + (s ? '?' + s : ''), { replace: true });
  };

  useEffect(() => {
    const t = setTimeout(() => { if (text.trim() !== q) setParam('q', text.trim()); }, 300);
    return () => clearTimeout(t);
  }, [text]);

  useEffect(() => { setPage(1); }, [q, status, gender, sort]);

  useEffect(() => {
    const ctrl = new AbortController();
    setLoading(true); setErr(null);
    api('/cats' + qs({ q, status, gender, sort, page, page_size: 20 }), { signal: ctrl.signal })
      .then((r) => setData((prev) => (page > 1 && prev ? { ...r, items: [...prev.items, ...r.items] } : r)))
      .catch((e) => { if (e.name !== 'AbortError') setErr(e.message); })
      .finally(() => setLoading(false));
    return () => ctrl.abort();
  }, [q, status, gender, sort, page]);

  return html`<div class="stack">
    <div class="row between">
      <h1>Cats</h1>
      ${can(PERM.CAT_WRITE) ? html`<${Link} to="/cats/new" class="btn">+ Register cat<//>` : null}
    </div>
    <input class="input" type="search" placeholder="Search name, CAT-ID, color, marks" aria-label="Search cats"
      value=${text} onChange=${(e) => setText(e.target.value)} />
    <div class="grid3">
      <select class="input compact" aria-label="Status" value=${status} onChange=${(e) => setParam('status', e.target.value)}>
        <option value="">All status</option>
        <option value="active">Active</option>
        <option value="missing">Missing</option>
        <option value="adopted">Adopted</option>
        <option value="deceased">Deceased</option>
        ${can(PERM.CAT_WRITE) ? html`<option value="archived">Archived</option>` : null}
      </select>
      <select class="input compact" aria-label="Sex" value=${gender} onChange=${(e) => setParam('gender', e.target.value)}>
        <option value="">Any sex</option>
        <option value="male">Male</option>
        <option value="female">Female</option>
        <option value="unknown">Unknown</option>
      </select>
      <select class="input compact" aria-label="Sort" value=${sort} onChange=${(e) => setParam('sort', e.target.value)}>
        <option value="name">Name A-Z</option>
        <option value="last_fed">Needs food first</option>
        <option value="last_seen">Not seen longest</option>
        <option value="newest">Newest</option>
        <option value="code">CAT-ID</option>
      </select>
    </div>
    <${ErrorBox} msg=${err} />
    ${data ? html`<div class="tiny muted">${data.total} cat${data.total === 1 ? '' : 's'}</div>` : null}
    <div class="stack-sm">${data && data.items.map((c) => html`<${CatRow} key=${c.id} cat=${c} />`)}</div>
    ${loading ? html`<${Loader} />` : null}
    ${!loading && data && data.items.length === 0
      ? html`<${Empty} title="No cats found" hint=${q || status || gender ? 'Try a different search or filter.' : 'No cats registered yet.'} />`
      : null}
    ${!loading && data && data.items.length < data.total
      ? html`<${Button} kind="secondary" class="block" onClick=${() => setPage((p) => p + 1)}>Load more<//>` : null}
  </div>`;
}

// ---------------- Cat profile ----------------
function mapLink(a) {
  if (a.latitude == null) return null;
  const url = `https://www.openstreetmap.org/?mlat=${a.latitude}&mlon=${a.longitude}#map=18/${a.latitude}/${a.longitude}`;
  return html`<a href=${url} target="_blank" rel="noopener noreferrer">map${a.location_accuracy_m ? ` (±${Math.round(a.location_accuracy_m)} m)` : ''}</a>`;
}

export function History({ catId, refreshKey, showCat }) {
  const [type, setType] = useState('');
  const [data, setData] = useState(null);
  const [page, setPage] = useState(1);
  const [err, setErr] = useState(null);
  useEffect(() => { setPage(1); }, [type, refreshKey]);
  useEffect(() => {
    const path = catId ? `/cats/${catId}/activities` : '/activities';
    api(path + qs({ type, page, page_size: 15 }))
      .then((r) => setData((prev) => (page > 1 && prev ? { ...r, items: [...prev.items, ...r.items] } : r)))
      .catch((e) => setErr(e.message));
  }, [catId, type, page, refreshKey]);

  return html`<div class="stack-sm">
    <div class="segment" role="tablist">
      ${[['', 'All'], ['feeding', 'Feedings'], ['sighting', 'Sightings']].map(([v, l]) =>
        html`<button key=${v} class=${type === v ? 'on' : ''} onClick=${() => setType(v)}>${l}</button>`)}
    </div>
    <${ErrorBox} msg=${err} />
    ${!data ? html`<${Loader} />` : data.items.length === 0 ? html`<${Empty} title="No records yet" />` : html`
      <ul class="timeline">
        ${data.items.map((a) => html`<li key=${a.id}>
          <div class=${'ico ' + a.activity_type} aria-hidden="true">${a.activity_type === 'feeding' ? '🍽' : '👁'}</div>
          <div class="minw0">
            <div class="row between" style=${{ alignItems: 'baseline' }}>
              <b style=${{ textTransform: 'capitalize' }}>${a.activity_type}${showCat ? html` · <${Link} to=${'/cats/' + a.cat_id}>${a.cat_name}<//>` : null}</b>
              <span class="tiny muted">${timeAgo(a.recorded_at)}</span>
            </div>
            <div class="small muted">${fmtDateTime(a.recorded_at)} · ${a.recorded_by.full_name || 'Someone'}
              ${a.method === 'qr_scan' ? html` · <span class="badge b-active">QR</span>` : null}</div>
            ${a.location_label || a.latitude != null ? html`<div class="small">📍 ${a.location_label || ''} ${mapLink(a)}</div>` : null}
            ${a.notes ? html`<div class="small" style=${{ marginTop: '2px' }}>${a.notes}</div>` : null}
          </div>
        </li>`)}
      </ul>
      ${data.items.length < data.total ? html`<${Button} kind="secondary" class="block" onClick=${() => setPage((p) => p + 1)}>Load more<//>` : null}
    `}
  </div>`;
}

export function CatPage({ id, qrToken }) {
  const { can } = useSession();
  const [cat, setCat] = useState(null);
  const [err, setErr] = useState(null);
  const [sheet, setSheet] = useState(null);
  const [tick, setTick] = useState(0);

  useEffect(() => {
    api('/cats/' + id).then(setCat).catch((e) => setErr(e.message));
  }, [id, tick]);

  if (err) return html`<div class="stack"><${ErrorBox} msg=${err} /><${Link} to="/" class="btn secondary">Back to catalog<//></div>`;
  if (!cat) return html`<${Loader} />`;

  const canFeed = can(PERM.FEEDING) && cat.status === 'active';
  const canSight = can(PERM.SIGHTING) && (cat.status === 'active' || cat.status === 'missing');

  return html`<div class="stack">
    ${qrToken ? html`<div class="alert ok"><b>Tag verified.</b> This is ${cat.name}'s current QR tag.</div>` : null}
    <${CatPhoto} cat=${cat} large=${true} />
    <div>
      <div class="row between">
        <h1>${cat.name}</h1>
        <${StatusBadge} status=${cat.status} />
      </div>
      <div class="muted">${cat.cat_code} · ${GENDER[cat.gender]} · ${cat.color}</div>
    </div>

    <div class="grid2">
      <div class="stat">
        <div class="k"><${FedDot} iso=${cat.last_fed_at} />Last fed</div>
        <div class="v" style=${{ fontSize: '19px' }}>${timeAgo(cat.last_fed_at)}</div>
        <div class="s">${cat.last_fed_at ? fmtDateTime(cat.last_fed_at) : 'No feeding recorded'}${cat.last_fed_by ? ' · ' + cat.last_fed_by : ''}</div>
      </div>
      <div class="stat">
        <div class="k">Last seen</div>
        <div class="v" style=${{ fontSize: '19px' }}>${timeAgo(cat.last_seen_at)}</div>
        <div class="s">${cat.last_seen_at ? fmtDateTime(cat.last_seen_at) : 'No sighting recorded'}${cat.last_seen_by ? ' · ' + cat.last_seen_by : ''}</div>
      </div>
    </div>

    ${canFeed || canSight ? html`<div class="grid2">
      ${canFeed ? html`<${Button} kind="ok big" onClick=${() => setSheet('feeding')}>🍽 Record feeding<//>` : null}
      ${canSight ? html`<${Button} kind=${canFeed ? 'secondary big' : 'big'} onClick=${() => setSheet('sighting')}>👁 Record sighting<//>` : null}
    </div>` : null}

    <div class="card">
      <dl class="kv">
        ${cat.distinguishing_marks ? html`<dt>Marks</dt><dd>${cat.distinguishing_marks}</dd>` : null}
        <dt>Registered</dt><dd>${fmtDate(cat.registered_at)}${cat.registered_by ? ' by ' + cat.registered_by : ''}</dd>
        ${cat.registration_location ? html`<dt>Found at</dt><dd>${cat.registration_location}</dd>` : null}
        ${cat.registration_notes ? html`<dt>Notes</dt><dd>${cat.registration_notes}</dd>` : null}
      </dl>
    </div>

    ${can(PERM.CAT_WRITE) ? html`<div class="grid2">
      <${Link} to=${`/cats/${cat.id}/edit`} class="btn secondary">Edit details<//>
      <${Link} to=${`/cats/${cat.id}/tag`} class="btn secondary">QR tag<//>
    </div>` : null}

    <div>
      <h2>${can(PERM.READ_ALL) ? 'Activity history' : 'My records for this cat'}</h2>
      <${History} catId=${cat.id} refreshKey=${tick} />
    </div>

    ${sheet ? html`<${RecordSheet} cat=${cat} type=${sheet} qrToken=${qrToken}
      onClose=${() => setSheet(null)} onSaved=${() => setTick((t) => t + 1)} />` : null}
  </div>`;
}

// ---------------- Register / edit ----------------
export function CatFormPage({ id }) {
  const toast = useToast();
  const editing = !!id;
  const [form, setForm] = useState({ name: '', gender: 'unknown', color: '', distinguishing_marks: '',
    registration_location: '', registration_notes: '', status: 'active' });
  const [photo, setPhoto] = useState(null); // { image, thumb, preview }
  const [current, setCurrent] = useState(null);
  const [loading, setLoading] = useState(editing);
  const [saving, setSaving] = useState(false);
  const [err, setErr] = useState(null);
  const fileRef = useRef(null);

  useEffect(() => {
    if (!editing) return;
    api('/cats/' + id).then((c) => {
      setCurrent(c);
      setForm({ name: c.name, gender: c.gender, color: c.color, distinguishing_marks: c.distinguishing_marks || '',
        registration_location: c.registration_location || '', registration_notes: c.registration_notes || '', status: c.status });
    }).catch((e) => setErr(e.message)).finally(() => setLoading(false));
  }, [id]);

  const set = (k) => (e) => setForm({ ...form, [k]: e.target.value });

  async function pick(e) {
    const f = e.target.files && e.target.files[0];
    if (!f) return;
    try { setPhoto(await preparePhoto(f)); } catch (x) { setErr(x.message); }
  }

  async function submit(e) {
    e.preventDefault();
    setSaving(true); setErr(null);
    try {
      const body = { ...form };
      if (!editing) delete body.status;
      const cat = editing
        ? await api('/cats/' + id, { method: 'PUT', body })
        : await api('/cats', { body });
      if (photo) {
        try { await api(`/cats/${cat.id}/photo`, { body: { image: photo.image, thumb: photo.thumb } }); }
        catch (x) { toast('Saved, but the photo failed: ' + x.message, 'err'); }
      }
      if (editing) { toast('Changes saved'); navigate('/cats/' + cat.id, { replace: true }); }
      else { toast(`Registered ${cat.cat_code}. Print its tag next.`); navigate(`/cats/${cat.id}/tag`, { replace: true }); }
    } catch (x) {
      setErr(x.message);
    } finally {
      setSaving(false);
    }
  }

  if (loading) return html`<${Loader} />`;
  const preview = photo ? photo.preview : current && (current.thumb_url || current.photo_url);

  return html`<form class="stack" onSubmit=${submit}>
    <h1>${editing ? 'Edit ' + (current ? current.name : 'cat') : 'Register a cat'}</h1>
    ${editing && current ? html`<div class="muted">${current.cat_code}</div>` : html`<div class="small muted">A unique CAT-ID and QR tag are created automatically.</div>`}

    <div class="row">
      ${preview ? html`<img class="photo" src=${preview} alt="Selected photo" style=${{ width: '88px', height: '88px' }} />`
        : html`<div class="photo" style=${{ width: '88px', height: '88px' }}>📷</div>`}
      <div class="stack-sm">
        <input ref=${fileRef} type="file" accept="image/*" capture="environment" hidden onChange=${pick} />
        <${Button} type="button" kind="secondary" onClick=${() => fileRef.current.click()}>${preview ? 'Change photo' : 'Take / choose photo'}<//>
        <div class="tiny muted">Resized on your phone before upload; location data is removed.</div>
      </div>
    </div>

    <${Field} label="Name"><input class="input" required maxlength="80" value=${form.name} onChange=${set('name')} placeholder="Temporary names are fine" /><//>
    <div class="grid2">
      <${Field} label="Sex">
        <select class="input" value=${form.gender} onChange=${set('gender')}>
          <option value="unknown">Unknown</option><option value="male">Male</option><option value="female">Female</option>
        </select>
      <//>
      <${Field} label="Color"><input class="input" required maxlength="80" value=${form.color} onChange=${set('color')} placeholder="Orange tabby" /><//>
    </div>
    <${Field} label="Distinguishing marks" hint="Ear tip, notch, tail kink, eye color...">
      <textarea class="input" maxlength="1000" value=${form.distinguishing_marks} onChange=${set('distinguishing_marks')}></textarea>
    <//>
    <${Field} label="Where it was found / registered">
      <input class="input" maxlength="200" value=${form.registration_location} onChange=${set('registration_location')} placeholder="Purok 3 basketball court" />
    <//>
    <${Field} label="Registration notes (admins only)">
      <textarea class="input" maxlength="2000" value=${form.registration_notes} onChange=${set('registration_notes')}></textarea>
    <//>
    ${editing ? html`<${Field} label="Status" hint="Archived hides the cat from feeders and residents (e.g. a duplicate).">
      <select class="input" value=${form.status} onChange=${set('status')}>
        <option value="active">Active</option><option value="missing">Missing</option><option value="adopted">Adopted</option>
        <option value="deceased">Deceased</option><option value="archived">Archived</option>
      </select>
    <//>` : null}
    <${ErrorBox} msg=${err} />
    <div class="row">
      <${Button} type="button" kind="secondary" style=${{ flex: 1 }} onClick=${() => history.back()}>Cancel<//>
      <${Button} type="submit" style=${{ flex: 2 }} loading=${saving}>${editing ? 'Save changes' : 'Register cat'}<//>
    </div>
  </form>`;
}

// ---------------- Printable QR tag ----------------
export function TagPage({ id }) {
  const { settings } = useSession();
  const toast = useToast();
  const [cat, setCat] = useState(null);
  const [err, setErr] = useState(null);
  const [busy, setBusy] = useState(false);

  useEffect(() => { api('/cats/' + id).then(setCat).catch((e) => setErr(e.message)); }, [id]);

  async function rotate() {
    if (!confirm(`Replace ${cat.name}'s tag? The current printed tag will stop working immediately.`)) return;
    setBusy(true);
    try { setCat(await api(`/cats/${id}/qr`, { method: 'POST', body: {} })); toast('New tag created. Print and attach it.'); }
    catch (e) { setErr(e.message); } finally { setBusy(false); }
  }

  if (err) return html`<${ErrorBox} msg=${err} />`;
  if (!cat) return html`<${Loader} />`;
  if (!cat.qr_token) return html`<${ErrorBox} msg="Only administrators can print tags." />`;
  const url = `${location.origin}/s/${cat.qr_token}`;

  return html`<div class="stack">
    <div class="noprint row between"><h1>QR tag</h1><${Link} to=${'/cats/' + id} class="btn ghost">Back<//></div>
    <div class="tag">
      <div class="tiny" style=${{ fontWeight: 700, color: '#9a3412' }}>${settings.community_name}</div>
      <${QrSvg} text=${url} />
      <div class="code">${cat.cat_code}</div>
      <div class="nm">${cat.name}</div>
      <div class="foot">Community cat · Scan with CAT-TRACK to log feeding</div>
    </div>
    <div class="noprint stack-sm">
      <${Button} class="block" onClick=${() => window.print()}>Print tag<//>
      <div class="tiny muted center">Laminate or use waterproof sticker paper. Tag issued ${fmtDate(cat.qr_token_rotated_at)}.</div>
      <${Button} kind="secondary" class="block" loading=${busy} onClick=${rotate}>Replace lost or copied tag<//>
    </div>
  </div>`;
}