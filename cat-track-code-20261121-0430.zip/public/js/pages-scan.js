// QR scanner and tag resolver.
import { Link, api, html, navigate, tagToken, useEffect, useRef, useState } from './lib.js';
import { Button, ErrorBox, Loader } from './components.js';
import { CatPage } from './pages-cats.js';

let jsqrLoading = null;
function loadJsQR() {
  if (window.jsQR) return Promise.resolve();
  if (!jsqrLoading) {
    jsqrLoading = new Promise((resolve, reject) => {
      const s = document.createElement('script');
      s.src = '/vendor/jsQR.js';
      s.onload = resolve;
      s.onerror = () => reject(new Error('Could not load the scanner.'));
      document.head.appendChild(s);
    });
  }
  return jsqrLoading;
}

export function ScanPage() {
  const videoRef = useRef(null);
  const [err, setErr] = useState(null);
  const [status, setStatus] = useState('Starting camera...');
  const [torch, setTorch] = useState(null); // null = unsupported
  const [bad, setBad] = useState(null);
  const trackRef = useRef(null);

  useEffect(() => {
    let stream = null;
    let stopped = false;
    let timer = null;
    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d', { willReadFrequently: true });

    async function start() {
      if (!window.isSecureContext) throw new Error('The camera needs a secure (https) connection.');
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) throw new Error('This browser cannot open the camera.');
      try {
        stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: { ideal: 'environment' } }, audio: false });
      } catch (e) {
        throw new Error(e && e.name === 'NotAllowedError'
          ? 'Camera permission was denied. Allow camera access for this site in your browser settings.'
          : 'Could not open the camera.');
      }
      if (stopped) { stream.getTracks().forEach((t) => t.stop()); return; }
      const v = videoRef.current;
      v.srcObject = stream;
      await v.play();
      const track = stream.getVideoTracks()[0];
      trackRef.current = track;
      const caps = track.getCapabilities ? track.getCapabilities() : {};
      if (caps.torch) setTorch(false);

      // Native detector (Android Chrome) is fast; jsQR is the universal fallback.
      let detector = null;
      if ('BarcodeDetector' in window) {
        try {
          const formats = await window.BarcodeDetector.getSupportedFormats();
          if (formats.includes('qr_code')) detector = new window.BarcodeDetector({ formats: ['qr_code'] });
        } catch { /* fall back */ }
      }
      if (!detector) await loadJsQR();
      setStatus('Point at the cat\'s QR tag');

      const tick = async () => {
        if (stopped) return;
        try {
          let value = null;
          if (v.readyState >= 2) {
            if (detector) {
              const codes = await detector.detect(v);
              value = codes[0] && codes[0].rawValue;
            } else {
              const w = 640, h = Math.round((v.videoHeight / v.videoWidth) * 640) || 480;
              canvas.width = w; canvas.height = h;
              ctx.drawImage(v, 0, 0, w, h);
              const img = ctx.getImageData(0, 0, w, h);
              const r = window.jsQR(img.data, w, h, { inversionAttempts: 'dontInvert' });
              value = r && r.data;
            }
          }
          if (value) {
            const token = tagToken(value);
            if (token) {
              if (navigator.vibrate) navigator.vibrate(60);
              stopped = true;
              navigate('/s/' + token, { replace: true });
              return;
            }
            setBad('That QR code is not a CAT-TRACK tag.');
          }
        } catch { /* keep scanning */ }
        timer = setTimeout(tick, 180);
      };
      tick();
    }

    start().catch((e) => setErr(e.message));
    return () => {
      stopped = true;
      clearTimeout(timer);
      if (stream) stream.getTracks().forEach((t) => t.stop());
    };
  }, []);

  async function toggleTorch() {
    try {
      await trackRef.current.applyConstraints({ advanced: [{ torch: !torch }] });
      setTorch(!torch);
    } catch { setTorch(null); }
  }

  return html`<div class="stack">
    <h1>Scan tag</h1>
    ${err ? html`<${ErrorBox} msg=${err} />` : html`
      <div class="scanbox">
        <video ref=${videoRef} playsInline=${true} muted=${true}></video>
        <div class="frame"></div>
        <div class="hint">${status}</div>
      </div>
      ${bad ? html`<div class="alert warn">${bad}</div>` : null}
      ${torch !== null ? html`<${Button} kind="secondary" class="block" onClick=${toggleTorch}>${torch ? 'Turn flashlight off' : 'Turn flashlight on'}<//>` : null}
    `}
    <div class="card small">
      <b>Tag damaged or won't scan?</b>
      <div class="muted">Find the cat by name or CAT-ID in the catalog and record from its profile.</div>
      <div class="mt"><${Link} to="/" class="btn secondary block">Search catalog<//></div>
    </div>
  </div>`;
}

/** /s/:token  opened by the in-app scanner or by any phone camera app. */
export function ResolvePage({ token }) {
  const [hit, setHit] = useState(null);
  const [err, setErr] = useState(null);
  useEffect(() => {
    setHit(null); setErr(null);
    api('/scan/' + encodeURIComponent(token)).then(setHit).catch((e) => setErr(e.message));
  }, [token]);
  if (err) return html`<div class="stack">
    <h1>Tag not recognized</h1>
    <${ErrorBox} msg=${err} />
    <${Link} to="/scan" class="btn block">Scan again<//>
    <${Link} to="/" class="btn secondary block">Search catalog<//>
  </div>`;
  if (!hit) return html`<${Loader} />`;
  return html`<${CatPage} id=${hit.cat.id} qrToken=${hit.qr_token} />`;
}