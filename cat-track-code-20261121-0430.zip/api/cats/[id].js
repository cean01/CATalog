// GET /api/cats/:id   profile with latest feeding/sighting
// PUT /api/cats/:id   edit details or status (administrators)
import { db } from 'hatchable';
import { GENDERS, P, STATUSES, audit, fail, getActor, oneOf, requirePerm, route, str, uuidParam } from 'lib/core.js';
import { getVisibleCat, loadCatRow, toCat } from 'lib/cats.js';

export const access = 'user';
export const methods = ['GET', 'PUT'];

const TEXT_FIELDS = {
  name: { max: 80, required: true, label: 'Name' },
  color: { max: 80, required: true, label: 'Color' },
  distinguishing_marks: { max: 1000, label: 'Distinguishing marks' },
  registration_location: { max: 200, label: 'Registration location' },
  registration_notes: { max: 2000, label: 'Registration notes' },
};

export default route(async (req, res) => {
  const actor = await getActor(req);
  const id = uuidParam(req.params.id, 'cat');

  if (req.method === 'GET') {
    const row = await getVisibleCat(actor, id);
    return res.json(await toCat(row, actor, { full: true }));
  }

  requirePerm(actor, P.CAT_WRITE, 'Only administrators can edit cats.');
  const before = await loadCatRow(id);
  if (!before) fail(404, 'Cat not found.');
  const b = req.body || {};
  const sets = [];
  const params = [id];
  const changes = {};
  for (const [key, opts] of Object.entries(TEXT_FIELDS)) {
    if (!(key in b)) continue;
    const v = str(b, key, opts);
    params.push(v);
    sets.push(`${key} = $${params.length}`);
    changes[key] = v;
  }
  if ('gender' in b) {
    params.push(oneOf(b.gender, GENDERS, 'Gender') || 'unknown');
    sets.push(`gender = $${params.length}::cat_gender`);
    changes.gender = params[params.length - 1];
  }
  if ('status' in b) {
    const s = oneOf(b.status, STATUSES, 'Status');
    if (!s) fail(422, 'Status is required.');
    params.push(s);
    sets.push(`status = $${params.length}::cat_status`);
    changes.status = s;
  }
  if (!sets.length) fail(422, 'Nothing to update.');
  await db.query(`UPDATE cats SET ${sets.join(', ')} WHERE id = $1`, params);
  const was = {};
  for (const k of Object.keys(changes)) was[k] = before[k];
  await audit(actor.user_id, 'cat.update', 'cat', id, { before: was, after: changes });
  res.json(await toCat(await loadCatRow(id), actor, { full: true }));
});