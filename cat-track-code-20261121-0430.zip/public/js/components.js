// Reusable UI pieces.
import {
  GENDER, Link, STATUS, api, getLocationFix, hoursSince, html, timeAgo, useEffect, useRef, useState, useToast, uuid,
} from './lib.js';

export const Loader = () => html`<div class="loader"><div class="spin" role="status" aria-label="Loading"></div></div>`;
export const ErrorBox = ({ msg }) => (msg ? html`<div class="alert err" role="alert">${msg}</div>` : null);
export const Empty = ({ title, hint }) => html`<div class="empty"><b>${title}</b>${hint || ''}</div>`;
export const StatusBadge = ({ status }) => html`<span class=${'badge b-' + status}>${STATUS[status] || status}</span>`;
export const RoleBadge = ({ role }) => html`<span class=${'badge b-' + role}>${role}</span>`;

export function Button({ kind = '', loading, children, class: cls = '', ...rest }) {
  return html`<button ...${rest} class=${`btn ${kind} ${cls}`} disabled=${!!(rest.disabled || loading)}>
    ${loading ? html`<span class="spin sm"></span>` : null}${children}
  </button>`;
}

export function Field({ label, hint, children }) {
  return html`<label class="field"><span>${label}</span>${children}${hint ? html`<small>${hint}</small>` : null}</label>`;
}

const CatSvg = html`<svg viewBox="0 0 64 64" fill="currentColor" aria-hidden="true"><path d="M14 50V22l10 8h16l10-8v28c0 4-4 6-8 6H22c-4 0-8-2-8-6z"/></svg>`;

export function CatPhoto({ cat, large }) {
  const src = large ? cat.photo_url || cat.thumb_url : cat.thumb_url;
  const cls = 'photo' + (large ? ' lg' : '');
  if (!src) return html`<div class=${cls} aria-label="No photo">${CatSvg}</div>`;
  return html`<img class=${cls} src=${src} alt=${'Photo of ' + cat.name} loading="lazy" />`;
}

/** Green under 12 h, amber under 24 h, red after (or never). */
export function FedDot({ iso }) {
  const h = hoursSince(iso);
  return html`<span class=${'dot ' + (h < 12 ? 'g' : h < 24 ? 'a' : 'r')} aria-hidden="true"></span>`;
}

export function CatRow({ cat }) {
  return html`<${Link} to=${'/cats/' + cat.id} class="catrow">
    <${CatPhoto} cat=${cat} />
    <div class="minw0">
      <div class="row" style=${{ gap: '8px' }}>
        <span class="name">${cat.name}</span>
        ${cat.status !== 'active' ? html`<${StatusBadge} status=${cat.status} />` : null}
      </div>
      <div class="meta">${cat.cat_code} · ${GENDER[cat.gender]} · ${cat.color}</div>
      <div class="times">
        <span><${FedDot} iso=${cat.last_fed_at} />Fed ${timeAgo(cat.last_fed_at)}</span>
        <span class="muted">Seen ${timeAgo(cat.last_seen_at)}</span>
      </div>
    </div>
  <//>`;
}

/**
 * Bottom sheet for Record Feeding / Record Sighting.
 * One request ID per sheet: pressing Save again after a network failure
 * retries the SAME record, so it can never be saved twice.
 */
export function RecordSheet({ cat, type, qrToken, onClose, onSaved }) {
  const toast = useToast();
  const requestId = useRef(uuid());
  const [useGps, setUseGps] = useState(true);
  const [fix, setFix] = useState(null);
  const [gpsMsg, setGpsMsg] = useState('Getting your location...');
  const [label, setLabel] = useState('');
  const [notes, setNotes] = useState('');
  const [saving, setSaving] = useState(false);
  const [err, setErr] = useState(null);

  useEffect(() => {
    if (!useGps) return;
    let off = false;
    setGpsMsg('Getting your location...');
    getLocationFix()
      .then((f) => { if (!off) { setFix(f); setGpsMsg(`Location captured (about ${Math.round(f.accuracy)} m)`); } })
      .catch((e) => { if (!off) setGpsMsg(e.message + ' You can still save without it.'); });
    return () => { off = true; };
  }, [useGps]);

  const recentlyFed = type === 'feeding' && hoursSince(cat.last_fed_at) < 2;
  const title = type === 'feeding' ? 'Record feeding' : 'Record sighting';

  async function save() {
    setSaving(true); setErr(null);
    try {
      const gps = useGps && fix ? { latitude: fix.latitude, longitude: fix.longitude, location_accuracy_m: fix.accuracy } : {};
      const r = await api(`/cats/${cat.id}/activities`, {
        body: {
          activity_type: type,
          method: qrToken ? 'qr_scan' : 'manual',
          qr_token: qrToken || undefined,
          ...gps,
          location_label: label.trim() || undefined,
          notes: notes.trim() || undefined,
          client_request_id: requestId.current,
        },
      });
      toast(r.duplicate ? 'Already saved earlier.' : `${type === 'feeding' ? 'Feeding' : 'Sighting'} saved for ${cat.name}`);
      onSaved && onSaved();
      onClose();
    } catch (e) {
      setErr(e.status === 0 ? e.message + ' Your entry is kept: press Save again to retry.' : e.message);
    } finally {
      setSaving(false);
    }
  }

  return html`<div class="sheet-back" role="dialog" aria-modal="true" aria-label=${title}
      onClick=${(e) => { if (e.target === e.currentTarget && !saving) onClose(); }}>
    <div class="sheet stack">
      <div class="grab"></div>
      <div>
        <h2 style=${{ marginBottom: '2px' }}>${title}</h2>
        <div class="small muted">${cat.name} · ${cat.cat_code}
          ${qrToken ? html` <span class="badge b-active">Tag scanned</span>` : null}</div>
      </div>
      ${recentlyFed ? html`<div class="alert warn">Heads up: ${cat.name} was fed ${timeAgo(cat.last_fed_at)}${cat.last_fed_by ? ' by ' + cat.last_fed_by : ''}.</div>` : null}
      <div class="card" style=${{ padding: '10px 12px' }}>
        <label class="row between">
          <span style=${{ fontWeight: 600, fontSize: '14px' }}>Attach my GPS location</span>
          <input type="checkbox" checked=${useGps} onChange=${(e) => setUseGps(e.target.checked)}
            style=${{ width: '22px', height: '22px', accentColor: 'var(--brand)' }} />
        </label>
        ${useGps ? html`<div class="tiny muted" style=${{ marginTop: '4px' }}>${gpsMsg}</div>` : null}
      </div>
      <${Field} label="Place (optional)" hint="e.g. Purok 3 basketball court">
        <input class="input" value=${label} maxlength="200" onChange=${(e) => setLabel(e.target.value)} />
      <//>
      <${Field} label="Notes (optional)">
        <textarea class="input" value=${notes} maxlength="1000" onChange=${(e) => setNotes(e.target.value)}
          placeholder=${type === 'feeding' ? 'Ate well, limping, with kittens...' : 'Condition, behaviour...'}></textarea>
      <//>
      <${ErrorBox} msg=${err} />
      <div class="tiny muted">The date and time are set by the server when you save.</div>
      <div class="row">
        <${Button} kind="secondary" style=${{ flex: 1 }} onClick=${onClose} disabled=${saving}>Cancel<//>
        <${Button} kind=${type === 'feeding' ? 'ok' : ''} style=${{ flex: 2 }} onClick=${save} loading=${saving}>Save ${type}<//>
      </div>
    </div>
  </div>`;
}

/** Draws a QR code as inline SVG using the vendored qrcode-generator. */
export function QrSvg({ text }) {
  const q = window.qrcode(0, 'Q'); // error level Q survives ~25% damage on outdoor tags
  q.addData(text);
  q.make();
  const svg = q.createSvgTag({ cellSize: 8, margin: 2, scalable: true });
  return html`<div class="qr" dangerouslySetInnerHTML=${{ __html: svg }}></div>`;
}