// GET /api/activities  activity feed. Feeders/admins see everyone's records
// (optionally ?user_id=); residents see only their own.
import { getActor, oneOf, pageParams, route } from 'lib/core.js';
import { listActivities } from 'lib/cats.js';

export const access = 'user';
export const methods = ['GET'];

export default route(async (req, res) => {
  const actor = await getActor(req);
  const q = req.query || {};
  const { page, size, offset } = pageParams(q);
  const type = oneOf(q.type, ['feeding', 'sighting'], 'Type');
  const userId = typeof q.user_id === 'string' && q.user_id.length <= 128 ? q.user_id : null;
  const data = await listActivities(actor, { type, userId, size, offset });
  res.json({ ...data, page, page_size: size });
});