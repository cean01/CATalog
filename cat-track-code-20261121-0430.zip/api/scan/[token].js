// GET /api/scan/:token  resolve a scanned QR tag to its cat (feeders, admins).
// Returns the token back so the client can submit method=qr_scan, which the
// server re-verifies against the cat's current token.
import { db } from 'hatchable';
import { P, TOKEN_RE, fail, getActor, requirePerm, route, safeEqual } from 'lib/core.js';
import { loadCatRow, toCat } from 'lib/cats.js';

export const access = 'user';
export const methods = ['GET'];

export default route(async (req, res) => {
  const actor = await getActor(req);
  requirePerm(actor, P.SCAN, 'Only community feeders and administrators can scan cat tags.');
  const token = String(req.params.token || '');
  if (!TOKEN_RE.test(token)) fail(404, 'This is not a CAT-TRACK tag.');
  const hit = (await db.query('SELECT id, qr_token, status FROM cats WHERE qr_token = $1', [token])).rows[0];
  if (!hit || !safeEqual(hit.qr_token, token)) fail(404, 'This tag is not registered or has been replaced.');
  if (hit.status === 'archived') fail(404, 'This tag belongs to an archived record.');
  const cat = await toCat(await loadCatRow(hit.id), actor, { full: true });
  res.json({ cat, qr_token: token });
});