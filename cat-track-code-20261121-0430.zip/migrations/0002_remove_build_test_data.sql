-- One-time cleanup of rows created while testing the build with the
-- platform's synthetic test account (test-user@test.invalid). Matches
-- nothing on forks or fresh installs. The append-only trigger and row
-- security are lifted only inside this migration's transaction; the next
-- deploy re-applies the [db.tables.activities] row rule.
ALTER TABLE activities DISABLE ROW LEVEL SECURITY;
ALTER TABLE activities DISABLE TRIGGER activities_no_change;
DELETE FROM activities WHERE user_id IN (SELECT user_id FROM app_profiles WHERE email = 'test-user@test.invalid');
ALTER TABLE activities ENABLE TRIGGER activities_no_change;
DELETE FROM audit_logs WHERE actor_id IN (SELECT user_id FROM app_profiles WHERE email = 'test-user@test.invalid');
DELETE FROM cats WHERE registered_by IN (SELECT user_id FROM app_profiles WHERE email = 'test-user@test.invalid');
DELETE FROM app_profiles WHERE email = 'test-user@test.invalid';
SELECT setval('cat_code_seq', COALESCE((SELECT max(substring(cat_code from 5)::int) FROM cats), 0) + 1, false);