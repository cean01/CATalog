// GET /api/users  list accounts with role filter and search (administrators)
import { db } from 'hatchable';
import { P, ROLES, getActor, oneOf, pageParams, requirePerm, route } from 'lib/core.js';

export const access = 'user';
export const methods = ['GET'];

export default route(async (req, res) => {
  const actor = await getActor(req);
  requirePerm(actor, P.USERS, 'Only administrators can manage users.');
  const q = req.query || {};
  const { page, size, offset } = pageParams(q, 25);
  const where = [];
  const params = [];
  const search = typeof q.q === 'string' ? q.q.trim().slice(0, 100) : '';
  if (search) {
    params.push('%' + search.replace(/[\\%_]/g, (m) => '\\' + m) + '%');
    where.push(`(email ILIKE $${params.length} OR full_name ILIKE $${params.length})`);
  }
  const role = oneOf(q.role, ROLES, 'Role');
  if (role) { params.push(role); where.push(`role = $${params.length}::app_role`); }
  const w = where.length ? 'WHERE ' + where.join(' AND ') : '';
  const total = (await db.query(`SELECT count(*)::int AS n FROM app_profiles ${w}`, params)).rows[0].n;
  params.push(size, offset);
  const { rows } = await db.query(
    `SELECT user_id AS id, email, full_name, role, is_active, created_at, last_seen_at FROM app_profiles ${w}
     ORDER BY is_active DESC, (role = 'admin') DESC, (role = 'feeder') DESC, lower(full_name), email
     LIMIT $${params.length - 1} OFFSET $${params.length}`,
    params,
  );
  res.json({ items: rows, total, page, page_size: size });
});