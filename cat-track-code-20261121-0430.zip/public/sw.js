// CAT-TRACK service worker.
// - App shell (HTML, JS, CSS, vendor libs): stale-while-revalidate, so the app
//   opens instantly and on weak signal, then updates itself in the background.
// - /api/* is NEVER cached: records must always be live and written to the server.
const SHELL = 'cattrack-shell-v2';
const PRECACHE = [
  '/', '/index.html', '/theme.css', '/app.css', '/manifest.webmanifest', '/icons/icon.svg',
  '/vendor/react.js', '/vendor/react-dom.js', '/vendor/htm.js', '/vendor/qrcode.js',
  '/js/main.js', '/js/lib.js', '/js/components.js', '/js/pages-cats.js', '/js/pages-scan.js', '/js/pages-admin.js',
];

self.addEventListener('install', (e) => {
  e.waitUntil(caches.open(SHELL).then((c) => c.addAll(PRECACHE)).catch(() => {}));
  self.skipWaiting();
});

self.addEventListener('activate', (e) => {
  e.waitUntil(caches.keys().then((keys) => Promise.all(keys.filter((k) => k !== SHELL).map((k) => caches.delete(k)))));
  self.clients.claim();
});

self.addEventListener('fetch', (e) => {
  const req = e.request;
  const url = new URL(req.url);
  if (req.method !== 'GET' || url.origin !== location.origin) return;
  if (url.pathname.startsWith('/api/') || url.pathname.startsWith('/__hatchable') || url.pathname === '/login') return;

  // Page navigations (SPA routes like /cats/123, /s/<token>) use the shell.
  if (req.mode === 'navigate') {
    e.respondWith(
      fetch(req).then((res) => {
        if (res.ok) caches.open(SHELL).then((c) => c.put('/index.html', res.clone()));
        return res;
      }).catch(() => caches.match('/index.html')),
    );
    return;
  }

  e.respondWith(
    caches.open(SHELL).then(async (c) => {
      const hit = await c.match(req);
      const net = fetch(req).then((res) => { if (res.ok) c.put(req, res.clone()); return res; }).catch(() => hit);
      return hit || net;
    }),
  );
});