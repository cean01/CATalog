// Administrator: dashboard, users & roles, audit log. Plus the "Me" page.
import { Link, PERM, ROLE, api, fmtDateTime, html, qs, timeAgo, useEffect, useSession, useState, useToast } from './lib.js';
import { Button, Empty, ErrorBox, Field, Loader, RoleBadge } from './components.js';
import { History } from './pages-cats.js';

function Stat({ k, v, s }) {
  return html`<div class="stat"><div class="k">${k}</div><div class="v">${v}</div>${s ? html`<div class="s">${s}</div>` : null}</div>`;
}

function Bars({ days }) {
  const max = Math.max(1, ...days.map((d) => d.feedings + d.sightings));
  return html`<div>
    <div class="bars" role="img" aria-label="Feedings and sightings per day, last 14 days">
      ${days.map((d) => html`<div class="col" key=${d.day} title=${`${d.day}: ${d.feedings} feedings, ${d.sightings} sightings`}>
        <div class="s" style=${{ height: (d.sightings / max) * 100 + '%' }}></div>
        <div class="f" style=${{ height: (d.feedings / max) * 100 + '%' }}></div>
      </div>`)}
    </div>
    <div class="bars-x">${days.map((d, i) => html`<span key=${d.day}>${i % 3 === 1 ? d.day.slice(8) : ''}</span>`)}</div>
    <div class="legend mt"><span><i style=${{ background: 'var(--brand)' }}></i>Feedings</span><span><i style=${{ background: '#7dd3fc' }}></i>Sightings</span></div>
  </div>`;
}

function AttentionList({ title, items, field, empty }) {
  return html`<div class="card">
    <h2>${title}</h2>
    ${items.length === 0 ? html`<div class="small muted">${empty}</div>` : html`<ul class="list-plain">
      ${items.map((c) => html`<li key=${c.id} class="row between">
        <${Link} to=${'/cats/' + c.id}><b>${c.name}</b> <span class="tiny muted">${c.cat_code}</span><//>
        <span class="small muted">${c[field] ? timeAgo(c[field]) : 'never'}</span>
      </li>`)}
    </ul>`}
  </div>`;
}

export function DashboardPage() {
  const [d, setD] = useState(null);
  const [err, setErr] = useState(null);
  useEffect(() => { api('/dashboard').then(setD).catch((e) => setErr(e.message)); }, []);
  if (err) return html`<${ErrorBox} msg=${err} />`;
  if (!d) return html`<${Loader} />`;
  const s = d.cats_by_status;
  return html`<div class="stack">
    <div class="row between"><h1>Dashboard</h1><${Link} to="/admin/audit" class="btn ghost">Audit log<//></div>
    <div class="grid2">
      <${Stat} k="Registered cats" v=${d.total_cats} s=${`${s.active} active · ${s.missing} missing`} />
      <${Stat} k="Fed today" v=${d.feedings_today} s=${`${d.sightings_today} sightings today`} />
      <${Stat} k="Adopted" v=${s.adopted} s=${`${s.deceased} deceased · ${s.archived} archived`} />
      <${Stat} k="Active feeders" v=${d.users_by_role.feeder || 0} s=${`${d.users_by_role.resident || 0} residents · ${d.users_by_role.admin || 0} admins`} />
    </div>
    <div class="card"><h2>Last 14 days</h2><${Bars} days=${d.last_14_days} /></div>
    <${AttentionList} title="Not fed in 24 hours" items=${d.not_fed_24h} field="last_fed_at" empty="Every active cat was fed in the last 24 hours." />
    <${AttentionList} title="Not seen in 7 days" items=${d.not_seen_7d} field="last_seen_at" empty="Every active cat was seen this week." />
    <div class="card">
      <h2>Top feeders (7 days)</h2>
      ${d.top_feeders_7d.length === 0 ? html`<div class="small muted">No feedings this week yet.</div>` : html`<ul class="list-plain">
        ${d.top_feeders_7d.map((f) => html`<li key=${f.user_id} class="row between"><span>${f.full_name || 'Unnamed'}</span><b>${f.feedings}</b></li>`)}
      </ul>`}
    </div>
    <div><h2>Recent activity</h2><${History} showCat=${true} /></div>
    <div class="tiny muted center">"Today" uses ${d.timezone} time.</div>
  </div>`;
}

function UserRow({ u, me, onChanged }) {
  const toast = useToast();
  const [busy, setBusy] = useState(false);
  async function update(body, msg) {
    setBusy(true);
    try { onChanged(await api('/users/' + encodeURIComponent(u.id), { method: 'PUT', body })); toast(msg); }
    catch (e) { toast(e.message, 'err'); } finally { setBusy(false); }
  }
  const self = u.id === me.id;
  return html`<div class="card stack-sm" style=${{ opacity: u.is_active ? 1 : 0.6 }}>
    <div class="row between">
      <div class="minw0">
        <b>${u.full_name || '(no name yet)'}</b>${self ? html` <span class="tiny muted">(you)</span>` : null}
        <div class="small muted" style=${{ overflow: 'hidden', textOverflow: 'ellipsis' }}>${u.email}</div>
      </div>
      <${RoleBadge} role=${u.role} />
    </div>
    <div class="tiny muted">Joined ${fmtDateTime(u.created_at)}${u.last_seen_at ? ' · active ' + timeAgo(u.last_seen_at) : ''}${u.is_active ? '' : ' · DISABLED'}</div>
    <div class="row">
      <select class="input compact" style=${{ flex: 2 }} value=${u.role} disabled=${busy || self} aria-label="Role"
        onChange=${(e) => update({ role: e.target.value }, `${u.full_name || u.email} is now ${ROLE[e.target.value]}`)}>
        <option value="resident">Resident</option><option value="feeder">Community Feeder</option><option value="admin">Administrator</option>
      </select>
      <${Button} kind=${u.is_active ? 'secondary' : ''} style=${{ flex: 1, minHeight: '40px' }} disabled=${self} loading=${busy}
        onClick=${() => update({ is_active: !u.is_active }, u.is_active ? 'Account disabled' : 'Account enabled')}>
        ${u.is_active ? 'Disable' : 'Enable'}
      <//>
    </div>
  </div>`;
}

export function UsersPage() {
  const { me } = useSession();
  const [q, setQ] = useState('');
  const [role, setRole] = useState('');
  const [data, setData] = useState(null);
  const [err, setErr] = useState(null);
  useEffect(() => {
    const t = setTimeout(() => {
      api('/users' + qs({ q: q.trim(), role, page_size: 100 })).then(setData).catch((e) => setErr(e.message));
    }, 250);
    return () => clearTimeout(t);
  }, [q, role]);
  const replace = (u) => setData((d) => ({ ...d, items: d.items.map((x) => (x.id === u.id ? u : x)) }));

  return html`<div class="stack">
    <h1>Users & roles</h1>
    <div class="alert info small">People sign up themselves with their email and start as <b>Residents</b>. Promote trusted volunteers to <b>Community Feeder</b> here.</div>
    <div class="row">
      <input class="input" type="search" placeholder="Search name or email" value=${q} onChange=${(e) => setQ(e.target.value)} style=${{ flex: 2 }} />
      <select class="input" value=${role} onChange=${(e) => setRole(e.target.value)} style=${{ flex: 1 }} aria-label="Role filter">
        <option value="">All</option><option value="admin">Admins</option><option value="feeder">Feeders</option><option value="resident">Residents</option>
      </select>
    </div>
    <${ErrorBox} msg=${err} />
    ${!data ? html`<${Loader} />` : data.items.length === 0 ? html`<${Empty} title="No users match" />`
      : html`<div class="stack-sm">${data.items.map((u) => html`<${UserRow} key=${u.id} u=${u} me=${me} onChanged=${replace} />`)}</div>`}
  </div>`;
}

const ACTION_LABEL = {
  'cat.create': 'Registered cat', 'cat.update': 'Edited cat', 'cat.photo': 'Changed cat photo', 'cat.qr_rotate': 'Replaced QR tag',
  'user.update': 'Changed user', 'user.join': 'New account', 'user.bootstrap_admin': 'Admin via settings',
};

export function AuditPage() {
  const [data, setData] = useState(null);
  const [page, setPage] = useState(1);
  const [err, setErr] = useState(null);
  useEffect(() => {
    api('/audit' + qs({ page, page_size: 30 }))
      .then((r) => setData((p) => (page > 1 && p ? { ...r, items: [...p.items, ...r.items] } : r)))
      .catch((e) => setErr(e.message));
  }, [page]);
  return html`<div class="stack">
    <div class="row between"><h1>Audit log</h1><${Link} to="/admin" class="btn ghost">Dashboard<//></div>
    <${ErrorBox} msg=${err} />
    ${!data ? html`<${Loader} />` : html`<div class="card"><ul class="list-plain">
      ${data.items.map((a) => html`<li key=${a.id}>
        <div class="row between"><b class="small">${ACTION_LABEL[a.action] || a.action}</b><span class="tiny muted">${fmtDateTime(a.created_at)}</span></div>
        <div class="tiny muted">by ${a.actor_name || a.actor_email || 'system'}${a.details && a.details.cat_code ? ' · ' + a.details.cat_code : ''}${a.details && a.details.email ? ' · ' + a.details.email : ''}</div>
        ${a.details && a.details.after ? html`<div class="tiny" style=${{ wordBreak: 'break-word' }}>${Object.entries(a.details.after).map(([k, v]) => `${k}: ${v}`).join(', ')}</div>` : null}
      </li>`)}
    </ul></div>
    ${data.items.length < data.total ? html`<${Button} kind="secondary" class="block" onClick=${() => setPage((p) => p + 1)}>Load more<//>` : null}`}
  </div>`;
}

export function MePage() {
  const { me, setMe, can } = useSession();
  const toast = useToast();
  const [name, setName] = useState(me.full_name);
  const [busy, setBusy] = useState(false);
  async function saveName(e) {
    e.preventDefault();
    setBusy(true);
    try { setMe(await api('/me', { method: 'PUT', body: { full_name: name } })); toast('Name saved'); }
    catch (x) { toast(x.message, 'err'); } finally { setBusy(false); }
  }
  async function signOut() {
    try { await window.hatchable.auth.signOut(); } finally { location.href = '/login'; }
  }
  return html`<div class="stack">
    <h1>My account</h1>
    <div class="card stack-sm">
      <div class="row between"><b>${me.email}</b><${RoleBadge} role=${me.role} /></div>
      <div class="small muted">${ROLE[me.role]}. ${me.role === 'resident' ? 'You can browse cats and report sightings. Ask an administrator if you help feed cats.' : me.role === 'feeder' ? 'You can scan tags and record feedings and sightings.' : 'You manage cats, tags, users and reports.'}</div>
    </div>
    <form class="card stack-sm" onSubmit=${saveName}>
      <${Field} label="Display name" hint="Shown on the records you create."><input class="input" required maxlength="120" value=${name} onChange=${(e) => setName(e.target.value)} /><//>
      <${Button} type="submit" kind="secondary" loading=${busy} disabled=${!name.trim() || name === me.full_name}>Save name<//>
    </form>
    <div><h2>${can(PERM.READ_ALL) ? 'Community activity' : 'My recent records'}</h2><${History} showCat=${true} /></div>
    <${Button} kind="secondary" class="block" onClick=${signOut}>Sign out<//>
  </div>`;
}