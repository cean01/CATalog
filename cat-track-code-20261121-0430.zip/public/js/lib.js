// Core helpers: htm binding, API client, tiny router, formatting, toasts.
// React, ReactDOM and htm are vendored UMD globals loaded by index.html.
const { useState, useEffect, useCallback, useContext, createContext, useRef } = React;
export const html = htm.bind(React.createElement);
export { useState, useEffect, useCallback, useContext, createContext, useRef };

// ---------------- API ----------------
export class ApiError extends Error {
  constructor(status, message) { super(message); this.status = status; }
}

export async function api(path, { method, body, signal } = {}) {
  let r;
  try {
    r = await fetch('/api' + path, {
      method: method || (body !== undefined ? 'POST' : 'GET'),
      headers: body !== undefined ? { 'Content-Type': 'application/json' } : {},
      body: body !== undefined ? JSON.stringify(body) : undefined,
      credentials: 'same-origin',
      signal,
    });
  } catch (e) {
    if (e && e.name === 'AbortError') throw e;
    throw new ApiError(0, 'No connection. Check your signal and try again.');
  }
  if (r.status === 401) {
    // Session ended: go sign in, then come back here.
    location.href = '/login?next=' + encodeURIComponent(location.pathname + location.search);
    throw new ApiError(401, 'Please sign in.');
  }
  let data = null;
  try { data = await r.json(); } catch { /* empty body */ }
  if (!r.ok) throw new ApiError(r.status, (data && (data.error || data.message)) || `Request failed (${r.status})`);
  return data;
}

export function qs(params) {
  const p = new URLSearchParams();
  for (const [k, v] of Object.entries(params)) if (v !== undefined && v !== null && v !== '') p.set(k, String(v));
  const s = p.toString();
  return s ? '?' + s : '';
}

// ---------------- router (History API; the platform serves index.html for unknown paths) ----------------
const listeners = new Set();
export function navigate(to, { replace = false } = {}) {
  if (replace) history.replaceState(null, '', to); else history.pushState(null, '', to);
  window.scrollTo(0, 0);
  listeners.forEach((fn) => fn());
}
window.addEventListener('popstate', () => listeners.forEach((fn) => fn()));

export function useLocation() {
  const [, force] = useState(0);
  useEffect(() => {
    const fn = () => force((n) => n + 1);
    listeners.add(fn);
    return () => listeners.delete(fn);
  }, []);
  return { path: location.pathname, search: new URLSearchParams(location.search) };
}

export function Link({ to, children, ...rest }) {
  const onClick = (e) => {
    if (e.metaKey || e.ctrlKey || e.shiftKey || e.button !== 0) return;
    e.preventDefault();
    navigate(to);
  };
  return html`<a href=${to} onClick=${onClick} ...${rest}>${children}</a>`;
}

/** Matches '/cats/:id' style patterns. Returns params or null. */
export function match(pattern, path) {
  const a = pattern.split('/').filter(Boolean);
  const b = path.split('/').filter(Boolean);
  if (a.length !== b.length) return null;
  const params = {};
  for (let i = 0; i < a.length; i++) {
    if (a[i].startsWith(':')) params[a[i].slice(1)] = decodeURIComponent(b[i]);
    else if (a[i] !== b[i]) return null;
  }
  return params;
}

// ---------------- session context ----------------
export const SessionCtx = createContext(null);
export const useSession = () => useContext(SessionCtx);
export const PERM = {
  CAT_READ: 'cat:read', CAT_WRITE: 'cat:write', CAT_QR: 'cat:qr', SCAN: 'scan',
  FEEDING: 'activity:feeding', SIGHTING: 'activity:sighting', READ_ALL: 'activity:read_all',
  USERS: 'user:manage', DASHBOARD: 'dashboard:read', AUDIT: 'audit:read',
};

// ---------------- toasts ----------------
const ToastCtx = createContext(() => {});
export const useToast = () => useContext(ToastCtx);
export function ToastProvider({ children }) {
  const [items, setItems] = useState([]);
  const push = useCallback((text, kind = 'ok') => {
    const id = Math.random();
    setItems((x) => [...x, { id, text, kind }]);
    setTimeout(() => setItems((x) => x.filter((t) => t.id !== id)), 3500);
  }, []);
  return html`<${ToastCtx.Provider} value=${push}>
    ${children}
    <div class="toasts" aria-live="polite">
      ${items.map((t) => html`<div key=${t.id} class=${'toast ' + (t.kind === 'err' ? 'err' : '')}>${t.text}</div>`)}
    </div>
  <//>`;
}

// ---------------- formatting ----------------
const rtf = new Intl.RelativeTimeFormat(undefined, { numeric: 'auto' });
export function timeAgo(iso) {
  if (!iso) return 'never';
  const diff = (new Date(iso).getTime() - Date.now()) / 1000;
  const abs = Math.abs(diff);
  if (abs < 45) return 'just now';
  if (abs < 3600) return rtf.format(Math.round(diff / 60), 'minute');
  if (abs < 86400) return rtf.format(Math.round(diff / 3600), 'hour');
  if (abs < 86400 * 30) return rtf.format(Math.round(diff / 86400), 'day');
  return fmtDate(iso);
}
export const fmtDateTime = (iso) => iso ? new Date(iso).toLocaleString(undefined, {
  month: 'short', day: 'numeric', year: 'numeric', hour: 'numeric', minute: '2-digit' }) : '-';
export const fmtDate = (iso) => iso ? new Date(iso).toLocaleDateString(undefined, {
  month: 'short', day: 'numeric', year: 'numeric' }) : '-';
export const hoursSince = (iso) => iso ? (Date.now() - new Date(iso).getTime()) / 3600000 : Infinity;

export const GENDER = { male: 'Male', female: 'Female', unknown: 'Unknown sex' };
export const STATUS = { active: 'Active', missing: 'Missing', adopted: 'Adopted', deceased: 'Deceased', archived: 'Archived' };
export const ROLE = { admin: 'Administrator', feeder: 'Community Feeder', resident: 'Resident' };

export function uuid() {
  if (crypto.randomUUID) return crypto.randomUUID();
  const b = crypto.getRandomValues(new Uint8Array(16));
  b[6] = (b[6] & 0x0f) | 0x40; b[8] = (b[8] & 0x3f) | 0x80;
  const h = [...b].map((x) => x.toString(16).padStart(2, '0')).join('');
  return `${h.slice(0, 8)}-${h.slice(8, 12)}-${h.slice(12, 16)}-${h.slice(16, 20)}-${h.slice(20)}`;
}

/** Pulls the tag token from a scanned value: https://host/s/<token> or a bare token. */
export function tagToken(raw) {
  const text = String(raw || '').trim();
  if (/^[A-Za-z0-9_-]{32,64}$/.test(text)) return text;
  try {
    const u = new URL(text);
    const m = u.pathname.match(/^\/s\/([A-Za-z0-9_-]{32,64})\/?$/);
    return m ? m[1] : null;
  } catch { return null; }
}

export function getLocationFix(timeout = 10000) {
  return new Promise((resolve, reject) => {
    if (!('geolocation' in navigator)) return reject(new Error('This device has no location support.'));
    navigator.geolocation.getCurrentPosition(
      (p) => resolve({
        latitude: Number(p.coords.latitude.toFixed(6)),
        longitude: Number(p.coords.longitude.toFixed(6)),
        accuracy: Math.round(p.coords.accuracy * 10) / 10,
      }),
      (e) => reject(new Error(e.code === 1 ? 'Location permission was denied.' : e.code === 3 ? 'Location took too long.' : 'Location unavailable.')),
      { enableHighAccuracy: true, timeout, maximumAge: 30000 },
    );
  });
}

/** Resize + re-encode a photo in the browser (also strips EXIF/GPS). */
export async function preparePhoto(file) {
  const img = await loadImage(file);
  const full = drawJpeg(img, 1280, false, 0.82);
  let fullData = full;
  if (fullData.length > 1_900_000) fullData = drawJpeg(img, 1024, false, 0.7);
  const thumb = drawJpeg(img, 360, true, 0.78);
  return { image: fullData.split(',')[1], thumb: thumb.split(',')[1], preview: thumb };
}
function loadImage(file) {
  return new Promise((resolve, reject) => {
    const url = URL.createObjectURL(file);
    const img = new Image();
    img.onload = () => { URL.revokeObjectURL(url); resolve(img); };
    img.onerror = () => { URL.revokeObjectURL(url); reject(new Error('That file is not a readable image.')); };
    img.src = url;
  });
}
function drawJpeg(img, max, square, quality) {
  const w = img.naturalWidth, h = img.naturalHeight;
  const c = document.createElement('canvas');
  if (square) {
    const s = Math.min(w, h);
    c.width = c.height = Math.min(max, s);
    c.getContext('2d').drawImage(img, (w - s) / 2, (h - s) / 2, s, s, 0, 0, c.width, c.height);
  } else {
    const k = Math.min(1, max / Math.max(w, h));
    c.width = Math.round(w * k); c.height = Math.round(h * k);
    c.getContext('2d').drawImage(img, 0, 0, c.width, c.height);
  }
  return c.toDataURL('image/jpeg', quality);
}