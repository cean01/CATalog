// PUT /api/users/:id  change role, active flag or name (administrators).
// Guards: the last active administrator cannot be demoted or disabled, and
// admins cannot remove their own admin access.
import { db } from 'hatchable';
import { P, ROLES, audit, fail, getActor, oneOf, requirePerm, route, str } from 'lib/core.js';

export const access = 'user';
export const methods = ['PUT'];

export default route(async (req, res) => {
  const actor = await getActor(req);
  requirePerm(actor, P.USERS, 'Only administrators can manage users.');
  const id = String(req.params.id || '').slice(0, 128);
  const target = (await db.query('SELECT * FROM app_profiles WHERE user_id = $1', [id])).rows[0];
  if (!target) fail(404, 'User not found.');

  const b = req.body || {};
  const changes = {};
  if ('role' in b) changes.role = oneOf(b.role, ROLES, 'Role');
  if ('is_active' in b) {
    if (typeof b.is_active !== 'boolean') fail(422, 'is_active must be true or false.');
    changes.is_active = b.is_active;
  }
  if ('full_name' in b) changes.full_name = str(b, 'full_name', { max: 120, required: true, label: 'Name' });
  if (!Object.keys(changes).length || changes.role === null) fail(422, 'Nothing to update.');

  const losesAdmin = target.role === 'admin' && ((changes.role && changes.role !== 'admin') || changes.is_active === false);
  if (losesAdmin) {
    if (target.user_id === actor.user_id) fail(409, 'You cannot remove your own administrator access.');
    const admins = (await db.query(`SELECT count(*)::int AS n FROM app_profiles WHERE role = 'admin' AND is_active`)).rows[0].n;
    if (admins <= 1) fail(409, 'This is the last active administrator.');
  }

  const { rows } = await db.query(
    `UPDATE app_profiles SET
       role = COALESCE($2::app_role, role),
       is_active = COALESCE($3, is_active),
       full_name = COALESCE($4, full_name)
     WHERE user_id = $1
     RETURNING user_id AS id, email, full_name, role, is_active, created_at, last_seen_at`,
    [id, changes.role ?? null, changes.is_active ?? null, changes.full_name ?? null],
  );
  const before = {};
  for (const k of Object.keys(changes)) before[k] = target[k];
  await audit(actor.user_id, 'user.update', 'user', id, { email: target.email, before, after: changes });
  res.json(rows[0]);
});