// POST /api/cats/:id/qr  replace the cat's QR tag token (administrators).
// The old printed tag stops working immediately: use when a tag is lost,
// damaged, stolen or copied. The QR image itself is drawn in the browser
// from the token returned in the admin profile.
import { db } from 'hatchable';
import { P, audit, fail, getActor, newToken, requirePerm, route, uuidParam } from 'lib/core.js';
import { loadCatRow, toCat } from 'lib/cats.js';

export const access = 'user';
export const methods = ['POST'];

export default route(async (req, res) => {
  const actor = await getActor(req);
  requirePerm(actor, P.CAT_QR, 'Only administrators can replace QR tags.');
  const id = uuidParam(req.params.id, 'cat');
  const { rows } = await db.query(
    'UPDATE cats SET qr_token = $2, qr_token_rotated_at = now() WHERE id = $1 RETURNING cat_code',
    [id, newToken()],
  );
  if (!rows[0]) fail(404, 'Cat not found.');
  await audit(actor.user_id, 'cat.qr_rotate', 'cat', id, { cat_code: rows[0].cat_code });
  res.json(await toCat(await loadCatRow(id), actor, { full: true }));
});